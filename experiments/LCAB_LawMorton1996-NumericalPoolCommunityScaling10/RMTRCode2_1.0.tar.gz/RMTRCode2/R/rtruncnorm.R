rtruncnorm <- function(lo, hi, mean, std) {
    rtnorm(lo, hi, mean, std)
}
